# API Usage Guide

This guide explains how to use the new API setup with axios and custom hooks in the Whale Tracker frontend.

## Environment Setup

The API base URL is configured using the `VITE_SERVER_URL` environment variable in the `.env` file:

```env
VITE_SERVER_URL=http://localhost:9090/api/v1
```

## Available API Endpoints

### 1. Trending Tokens

```typescript
import { trendingTokensAPI } from "../lib/api"

// Get trending tokens with limit
const response = await trendingTokensAPI.getTrendingTokens(50)
```

### 2. Whale Data

```typescript
import { whaleAPI } from "../lib/api"

// Get whales with optional parameters
const response = await whaleAPI.getWhales({ limit: 20, offset: 0 })

// Get whale transactions
const response = await whaleAPI.getWhaleTransactions({ limit: 50 })
```

### 3. Token Data

```typescript
import { tokenAPI } from "../lib/api"

// Get tokens with optional parameters
const response = await tokenAPI.getTokens({ symbol: "BTC" })
```

### 4. Insights

```typescript
import { insightAPI } from "../lib/api"

// Get insights with optional parameters
const response = await insightAPI.getInsights({ limit: 10 })
```

### 5. Influencers

```typescript
import { influencerAPI } from "../lib/api"

// Get influencers with optional parameters
const response = await influencerAPI.getInfluencers({ limit: 20 })
```

## Using Custom Hooks

### Basic API Hook

```typescript
import { useApi } from '../lib/useApi';

function MyComponent() {
  const { data, loading, error, execute } = useApi(async () => {
    const { trendingTokensAPI } = await import('../lib/api');
    return trendingTokensAPI.getTrendingTokens(50);
  });

  const handleFetch = () => {
    execute();
  };

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;

  return (
    <div>
      {/* Render your data */}
      <button onClick={handleFetch}>Fetch Data</button>
    </div>
  );
}
```

### Specialized Hooks

#### Trending Tokens Hook

```typescript
import { useTrendingTokens } from "../lib/useApi"

function TrendingTokensComponent() {
  const { data, loading, error, fetchTrendingTokens } = useTrendingTokens()

  useEffect(() => {
    fetchTrendingTokens(50)
  }, [fetchTrendingTokens])

  // ... rest of component
}
```

#### Whale Data Hook

```typescript
import { useWhales } from "../lib/useApi"

function WhalesComponent() {
  const { data, loading, error, fetchWhales } = useWhales()

  const handleFetch = () => {
    fetchWhales({ limit: 20 })
  }

  // ... rest of component
}
```

## TypeScript Support

All API responses are properly typed. Import the types you need:

```typescript
import type {
  TrendingTokensResponse,
  WhaleResponse,
  TransactionResponse,
  TokenResponse,
  InsightResponse,
  InfluencerResponse,
} from "../lib/types"
```

## Error Handling

The API setup includes automatic error handling:

- **401 Unauthorized**: Logs unauthorized access
- **500 Server Error**: Logs server errors
- **Network Errors**: Handled gracefully with user-friendly messages

## Request/Response Interceptors

### Request Interceptor

Automatically adds common headers and can be extended to include authentication tokens:

```typescript
// In api.ts - uncomment and modify as needed
api.interceptors.request.use((config) => {
  const token = localStorage.getItem("token")
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})
```

### Response Interceptor

Handles common HTTP status codes and provides centralized error handling.

## Example Component

See `src/components/common/TrendingTokensExample.tsx` for a complete example of how to use the API setup.

## Best Practices

1. **Use the custom hooks** instead of calling the API directly
2. **Handle loading and error states** in your components
3. **Use TypeScript types** for better development experience
4. **Reset state** when needed using the `reset()` function
5. **Use the execute function** for manual API calls

## Troubleshooting

### CORS Issues

Make sure your server CORS configuration allows your frontend origin.

### Environment Variable Not Working

- Ensure the `.env` file is in the root of your frontend project
- Restart your development server after changing environment variables
- Check that the variable name starts with `VITE_`

### Type Errors

- Import the correct types from `../lib/types`
- Use the generic type parameters when calling API functions
- Check that your API response matches the expected type structure
