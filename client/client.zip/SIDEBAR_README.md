# Whale Tracker V2 - Sidebar System

## Overview

This document describes the responsive sidebar system implemented for the Whale Tracker V2 application.

## Features

### 🎯 Responsive Design

- **Desktop**: Sidebar is always visible on the left side
- **Mobile**: Sidebar slides in/out with hamburger menu
- **Tablet**: Adaptive layout that works on all screen sizes

### 🧭 Navigation Structure

The sidebar includes three main categories:

#### 1. Alpha Whales

- **Alpha Stream** (`/`) - Home page with real-time whale transactions
- **Top Coins** (`/top-coins`) - Highest performing cryptocurrencies

#### 2. Influencer Intel

- **KOL Feed** (`/kol-feed`) - Key Opinion Leader insights and posts
- **Top KOL Coins** (`/top-kol-coins`) - Coins with highest KOL mentions

#### 3. Alpha Insights

- **Whales Leaderboard** (`/whales-leaderboard`) - Top performing whale wallets
- **Signal Engine** (`/signal-engine`) - AI-powered trading signals

### 📱 Mobile Features

- **Hamburger Menu**: Toggle sidebar visibility
- **Overlay**: Dark overlay when sidebar is open
- **Auto-close**: Sidebar closes automatically on route change
- **Escape Key**: Close sidebar using ESC key
- **Touch Friendly**: Optimized for mobile touch interactions

### 🎨 UI Components

#### Header

- Logo and branding
- Trending coins display
- Search functionality
- Mobile menu toggle
- Visualize button

#### Filter Bar

- Transaction type filters (All, Buy, Sell)
- Hotness score dropdown
- Amount range dropdown
- Tags filter dropdown
- Advanced filter options

#### Sidebar

- Category-based navigation
- Active route highlighting
- User profile section
- Social media links
- Responsive behavior

## Technical Implementation

### File Structure

```
src/
├── components/
│   └── layouts/
│       ├── MainLayout.tsx      # Main layout wrapper
│       ├── Sidebar.tsx         # Responsive sidebar
│       ├── Header.tsx          # Top header with search
│       ├── FilterBar.tsx       # Transaction filters
│       └── index.ts            # Component exports
├── pages/
│   ├── home/                   # Alpha Stream
│   ├── top-coins/             # Top Coins
│   ├── kol-feed/              # KOL Feed
│   ├── top-kol-coins/         # Top KOL Coins
│   ├── whales-leaderboard/    # Whales Leaderboard
│   ├── signal-engine/         # Signal Engine
│   └── index.ts               # Page exports
└── routes/
    └── routes.tsx             # Application routing
```

### Key Technologies

- **React Router DOM**: Client-side routing
- **Tailwind CSS**: Styling and responsive design
- **Lucide React**: Icon library
- **TypeScript**: Type safety

### State Management

- **Local State**: Sidebar open/close state
- **Route State**: Active navigation highlighting
- **Responsive State**: Mobile vs desktop behavior

## Usage

### Starting the Application

```bash
cd client/whale-tracking
npm install
npm run dev
```

### Navigation

1. **Desktop**: Click on sidebar navigation items
2. **Mobile**: Use hamburger menu to open sidebar, then tap navigation items
3. **Route Changes**: Automatically updates active state and closes mobile sidebar

### Customization

- **Colors**: Modify Tailwind classes in component files
- **Navigation**: Update `navigationItems` array in `Sidebar.tsx`
- **Pages**: Add new pages in the `pages/` directory and update routes
- **Styling**: Customize CSS classes and Tailwind utilities

## Responsive Breakpoints

- **Mobile**: `< 768px` - Sidebar slides in/out
- **Tablet**: `768px - 1024px` - Adaptive layout
- **Desktop**: `> 1024px` - Sidebar always visible

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- Mobile browsers (iOS Safari, Chrome Mobile)

## Performance Features

- **Lazy Loading**: Components load on demand
- **Smooth Animations**: CSS transitions for sidebar
- **Optimized Rendering**: React best practices
- **Mobile Optimization**: Touch-friendly interactions

## Future Enhancements

- [ ] Dark/Light theme toggle
- [ ] Sidebar collapse/expand on desktop
- [ ] Customizable navigation order
- [ ] User preferences storage
- [ ] Advanced search functionality
- [ ] Real-time notifications
- [ ] Multi-language support
