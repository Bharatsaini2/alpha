# Jupiter Swap Frontend Integration Guide

## Overview

This guide explains how to integrate the Jupiter Swap Engine into the AlphaBlock AI frontend. The swap feature allows users to trade Solana tokens directly from the application with a 0.75% platform fee.

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    React Frontend                           │
│                                                             │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐ │
│  │ Swap UI      │───▶│ Swap Hook    │───▶│ API Client   │ │
│  │ Component    │    │ (useSwap)    │    │ (api.ts)     │ │
│  └──────────────┘    └──────────────┘    └──────┬───────┘ │
│                                                   │         │
└───────────────────────────────────────────────────┼─────────┘
                                                    │ HTTP
                                                    ▼
                                          ┌─────────────────┐
                                          │ Backend API     │
                                          │ /api/v1/trade/* │
                                          └─────────────────┘
```

## Step 1: Update API Client

Add the swap endpoints to your API client (`src/lib/api.ts`):

```typescript
// src/lib/api.ts

import axios from 'axios';

const API_BASE_URL = import.meta.env.VITE_SERVER_URL || 'http://localhost:9090';

export const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
  withCredentials: true,
});

// Jupiter Swap API Types
export interface SwapQuoteParams {
  inputMint: string;
  outputMint: string;
  amount: number;
  slippageBps?: number;
}

export interface SwapQuoteResponse {
  success: boolean;
  data: {
    inputMint: string;
    outputMint: string;
    inAmount: string;
    outAmount: string;
    otherAmountThreshold: string;
    swapMode: string;
    slippageBps: number;
    platformFee: {
      amount: string;
      mint: string;
      pct: number;
    };
    priceImpactPct: string;
    routePlan: any[];
  };
}

export interface SwapTransactionRequest {
  quoteResponse: SwapQuoteResponse['data'];
  userPublicKey: string;
  wrapAndUnwrapSol?: boolean;
  prioritizationFeeLamports?: number;
}

export interface SwapTransactionResponse {
  success: boolean;
  data: {
    swapTransaction: string;
    lastValidBlockHeight: number;
  };
}

export interface TrackTradeRequest {
  signature: string;
  walletAddress: string;
  inputMint: string;
  outputMint: string;
  inputAmount: number;
  outputAmount: number;
  platformFee: number;
  timestamp?: string;
}

export interface TrackTradeResponse {
  success: boolean;
  message: string;
  trade: {
    signature: string;
    walletAddress: string;
    inputMint: string;
    outputMint: string;
    inputAmount: number;
    outputAmount: number;
    platformFee: number;
    timestamp: string;
  };
}

// Jupiter Swap API Endpoints
export const swapAPI = {
  // Get swap quote
  getQuote: async (params: SwapQuoteParams): Promise<SwapQuoteResponse> => {
    const response = await api.get('/api/v1/trade/quote', { params });
    return response.data;
  },

  // Generate swap transaction
  getSwapTransaction: async (
    request: SwapTransactionRequest
  ): Promise<SwapTransactionResponse> => {
    const response = await api.post('/api/v1/trade/swap', request);
    return response.data;
  },

  // Track completed trade
  trackTrade: async (request: TrackTradeRequest): Promise<TrackTradeResponse> => {
    const response = await api.post('/api/v1/trade/track', request);
    return response.data;
  },
};
```

## Step 2: Create Swap Hook

Create a custom hook to manage swap state (`src/hooks/useSwap.ts`):

```typescript
// src/hooks/useSwap.ts

import { useState, useCallback } from 'react';
import { useConnection, useWallet } from '@solana/wallet-adapter-react';
import { Transaction, VersionedTransaction } from '@solana/web3.js';
import { swapAPI, SwapQuoteParams, SwapQuoteResponse } from '@/lib/api';

interface UseSwapReturn {
  quote: SwapQuoteResponse['data'] | null;
  loading: boolean;
  error: string | null;
  getQuote: (params: SwapQuoteParams) => Promise<void>;
  executeSwap: () => Promise<string | null>;
  trackSwap: (signature: string) => Promise<void>;
}

export const useSwap = (): UseSwapReturn => {
  const { connection } = useConnection();
  const { publicKey, signTransaction, signAllTransactions } = useWallet();
  
  const [quote, setQuote] = useState<SwapQuoteResponse['data'] | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Get swap quote
  const getQuote = useCallback(async (params: SwapQuoteParams) => {
    if (!publicKey) {
      setError('Wallet not connected');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const response = await swapAPI.getQuote(params);
      setQuote(response.data);
    } catch (err: any) {
      const errorMessage = err.response?.data?.error?.message || 'Failed to get quote';
      setError(errorMessage);
      console.error('Quote error:', err);
    } finally {
      setLoading(false);
    }
  }, [publicKey]);

  // Execute swap transaction
  const executeSwap = useCallback(async (): Promise<string | null> => {
    if (!publicKey || !signTransaction || !quote) {
      setError('Missing requirements for swap');
      return null;
    }

    setLoading(true);
    setError(null);

    try {
      // Get swap transaction from backend
      const response = await swapAPI.getSwapTransaction({
        quoteResponse: quote,
        userPublicKey: publicKey.toBase58(),
        wrapAndUnwrapSol: true,
      });

      // Deserialize transaction
      const swapTransactionBuf = Buffer.from(
        response.data.swapTransaction,
        'base64'
      );
      
      let transaction: Transaction | VersionedTransaction;
      
      try {
        transaction = VersionedTransaction.deserialize(swapTransactionBuf);
      } catch {
        transaction = Transaction.from(swapTransactionBuf);
      }

      // Sign transaction
      const signedTransaction = await signTransaction(transaction);

      // Send transaction
      const rawTransaction = signedTransaction.serialize();
      const signature = await connection.sendRawTransaction(rawTransaction, {
        skipPreflight: false,
        maxRetries: 3,
      });

      // Confirm transaction
      const confirmation = await connection.confirmTransaction(
        signature,
        'confirmed'
      );

      if (confirmation.value.err) {
        throw new Error('Transaction failed');
      }

      return signature;
    } catch (err: any) {
      const errorMessage = err.response?.data?.error?.message || 
                          err.message || 
                          'Failed to execute swap';
      setError(errorMessage);
      console.error('Swap error:', err);
      return null;
    } finally {
      setLoading(false);
    }
  }, [publicKey, signTransaction, quote, connection]);

  // Track completed swap
  const trackSwap = useCallback(async (signature: string) => {
    if (!publicKey || !quote) {
      return;
    }

    try {
      await swapAPI.trackTrade({
        signature,
        walletAddress: publicKey.toBase58(),
        inputMint: quote.inputMint,
        outputMint: quote.outputMint,
        inputAmount: Number(quote.inAmount),
        outputAmount: Number(quote.outAmount),
        platformFee: Number(quote.platformFee.amount),
      });
    } catch (err) {
      console.error('Failed to track swap:', err);
      // Don't throw - tracking is non-critical
    }
  }, [publicKey, quote]);

  return {
    quote,
    loading,
    error,
    getQuote,
    executeSwap,
    trackSwap,
  };
};
```

## Step 3: Create Swap UI Component

Create a swap interface component (`src/components/SwapWidget.tsx`):

```typescript
// src/components/SwapWidget.tsx

import React, { useState, useEffect } from 'react';
import { useWallet } from '@solana/wallet-adapter-react';
import { useSwap } from '@/hooks/useSwap';
import { PublicKey } from '@solana/web3.js';

// Common token addresses
const TOKENS = {
  SOL: 'So11111111111111111111111111111111111111112',
  USDC: 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v',
  USDT: 'Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB',
};

export const SwapWidget: React.FC = () => {
  const { publicKey, connected } = useWallet();
  const { quote, loading, error, getQuote, executeSwap, trackSwap } = useSwap();

  const [inputToken, setInputToken] = useState(TOKENS.SOL);
  const [outputToken, setOutputToken] = useState(TOKENS.USDC);
  const [amount, setAmount] = useState('');
  const [slippage, setSlippage] = useState(50); // 0.5%

  // Get quote when inputs change
  useEffect(() => {
    if (!amount || !connected) return;

    const debounce = setTimeout(() => {
      const amountInSmallestUnit = parseFloat(amount) * 1e9; // Assuming 9 decimals
      
      getQuote({
        inputMint: inputToken,
        outputMint: outputToken,
        amount: amountInSmallestUnit,
        slippageBps: slippage,
      });
    }, 500);

    return () => clearTimeout(debounce);
  }, [amount, inputToken, outputToken, slippage, connected, getQuote]);

  const handleSwap = async () => {
    if (!quote) return;

    const signature = await executeSwap();
    
    if (signature) {
      // Track the swap
      await trackSwap(signature);
      
      // Show success message
      alert(`Swap successful! Signature: ${signature}`);
      
      // Reset form
      setAmount('');
    }
  };

  const handleFlipTokens = () => {
    setInputToken(outputToken);
    setOutputToken(inputToken);
  };

  if (!connected) {
    return (
      <div className="swap-widget">
        <p>Please connect your wallet to swap tokens</p>
      </div>
    );
  }

  return (
    <div className="swap-widget">
      <h2>Swap Tokens</h2>
      
      {/* Input Token */}
      <div className="token-input">
        <label>From</label>
        <select 
          value={inputToken} 
          onChange={(e) => setInputToken(e.target.value)}
        >
          <option value={TOKENS.SOL}>SOL</option>
          <option value={TOKENS.USDC}>USDC</option>
          <option value={TOKENS.USDT}>USDT</option>
        </select>
        <input
          type="number"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          placeholder="0.0"
          min="0"
          step="0.01"
        />
      </div>

      {/* Flip Button */}
      <button onClick={handleFlipTokens} className="flip-button">
        ⇅
      </button>

      {/* Output Token */}
      <div className="token-input">
        <label>To</label>
        <select 
          value={outputToken} 
          onChange={(e) => setOutputToken(e.target.value)}
        >
          <option value={TOKENS.SOL}>SOL</option>
          <option value={TOKENS.USDC}>USDC</option>
          <option value={TOKENS.USDT}>USDT</option>
        </select>
        <input
          type="text"
          value={quote ? (Number(quote.outAmount) / 1e9).toFixed(6) : '0.0'}
          readOnly
          placeholder="0.0"
        />
      </div>

      {/* Slippage Settings */}
      <div className="slippage-settings">
        <label>Slippage Tolerance: {slippage / 100}%</label>
        <input
          type="range"
          min="10"
          max="1000"
          value={slippage}
          onChange={(e) => setSlippage(Number(e.target.value))}
        />
      </div>

      {/* Quote Details */}
      {quote && (
        <div className="quote-details">
          <div className="detail-row">
            <span>Rate:</span>
            <span>
              1 {inputToken === TOKENS.SOL ? 'SOL' : 'Token'} = 
              {(Number(quote.outAmount) / Number(quote.inAmount)).toFixed(6)}
            </span>
          </div>
          <div className="detail-row">
            <span>Platform Fee (0.75%):</span>
            <span>{(Number(quote.platformFee.amount) / 1e9).toFixed(6)}</span>
          </div>
          <div className="detail-row">
            <span>Price Impact:</span>
            <span className={Number(quote.priceImpactPct) > 1 ? 'warning' : ''}>
              {quote.priceImpactPct}%
            </span>
          </div>
        </div>
      )}

      {/* Error Message */}
      {error && (
        <div className="error-message">
          {error}
        </div>
      )}

      {/* Swap Button */}
      <button
        onClick={handleSwap}
        disabled={!quote || loading || !amount}
        className="swap-button"
      >
        {loading ? 'Processing...' : 'Swap'}
      </button>

      {/* Disclaimer */}
      <p className="disclaimer">
        All swaps include a 0.75% platform fee
      </p>
    </div>
  );
};
```

## Step 4: Add Styling

Add styles for the swap widget (`src/style/swap.css`):

```css
/* src/style/swap.css */

.swap-widget {
  max-width: 480px;
  margin: 0 auto;
  padding: 24px;
  background: rgba(20, 20, 30, 0.8);
  border-radius: 16px;
  border: 1px solid rgba(255, 255, 255, 0.1);
}

.swap-widget h2 {
  margin-bottom: 24px;
  font-size: 24px;
  font-weight: 600;
}

.token-input {
  margin-bottom: 16px;
  padding: 16px;
  background: rgba(0, 0, 0, 0.3);
  border-radius: 12px;
}

.token-input label {
  display: block;
  margin-bottom: 8px;
  font-size: 14px;
  color: rgba(255, 255, 255, 0.6);
}

.token-input select,
.token-input input {
  width: 100%;
  padding: 12px;
  background: rgba(255, 255, 255, 0.05);
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: 8px;
  color: white;
  font-size: 16px;
}

.token-input input[readonly] {
  opacity: 0.6;
  cursor: not-allowed;
}

.flip-button {
  display: block;
  margin: -8px auto 16px;
  padding: 8px 16px;
  background: rgba(255, 255, 255, 0.1);
  border: none;
  border-radius: 8px;
  color: white;
  font-size: 20px;
  cursor: pointer;
  transition: all 0.2s;
}

.flip-button:hover {
  background: rgba(255, 255, 255, 0.2);
  transform: rotate(180deg);
}

.slippage-settings {
  margin: 16px 0;
  padding: 12px;
  background: rgba(0, 0, 0, 0.2);
  border-radius: 8px;
}

.slippage-settings label {
  display: block;
  margin-bottom: 8px;
  font-size: 14px;
}

.slippage-settings input[type="range"] {
  width: 100%;
}

.quote-details {
  margin: 16px 0;
  padding: 12px;
  background: rgba(0, 0, 0, 0.2);
  border-radius: 8px;
  font-size: 14px;
}

.detail-row {
  display: flex;
  justify-content: space-between;
  margin-bottom: 8px;
}

.detail-row:last-child {
  margin-bottom: 0;
}

.detail-row .warning {
  color: #ff6b6b;
}

.error-message {
  margin: 16px 0;
  padding: 12px;
  background: rgba(255, 0, 0, 0.1);
  border: 1px solid rgba(255, 0, 0, 0.3);
  border-radius: 8px;
  color: #ff6b6b;
  font-size: 14px;
}

.swap-button {
  width: 100%;
  padding: 16px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border: none;
  border-radius: 12px;
  color: white;
  font-size: 18px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s;
}

.swap-button:hover:not(:disabled) {
  transform: translateY(-2px);
  box-shadow: 0 8px 16px rgba(102, 126, 234, 0.4);
}

.swap-button:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.disclaimer {
  margin-top: 12px;
  text-align: center;
  font-size: 12px;
  color: rgba(255, 255, 255, 0.4);
}
```

## Step 5: Add to Your Application

Add the swap widget to your app (`src/App.tsx` or create a new page):

```typescript
// src/pages/swap/SwapPage.tsx

import React from 'react';
import { SwapWidget } from '@/components/SwapWidget';
import '@/style/swap.css';

export const SwapPage: React.FC = () => {
  return (
    <div className="swap-page">
      <div className="container">
        <h1>Token Swap</h1>
        <p>Swap Solana tokens with the best rates from Jupiter</p>
        <SwapWidget />
      </div>
    </div>
  );
};
```

Add route in your router configuration:

```typescript
// src/routes/index.tsx

import { SwapPage } from '@/pages/swap/SwapPage';

// Add to your routes
{
  path: '/swap',
  element: <SwapPage />,
}
```

## Step 6: Environment Configuration

Update your `.env` file:

```bash
# Frontend .env
VITE_SERVER_URL=http://localhost:9090
VITE_API_REOWNKIT_PROJECTID=your_project_id
```

## Testing the Integration

### 1. Start the Backend

```bash
cd whale-trackerV2-2/server
npm run dev
```

### 2. Start the Frontend

```bash
cd whale-trackerV2-2/client/whale-tracking
npm run dev
```

### 3. Test the Flow

1. Connect your Solana wallet (Phantom, Solflare, etc.)
2. Navigate to `/swap` page
3. Enter an amount to swap
4. Review the quote (should show 0.75% platform fee)
5. Click "Swap" button
6. Approve transaction in wallet
7. Wait for confirmation
8. Check that trade is tracked in database

## Error Handling

The integration includes comprehensive error handling:

- **Wallet not connected**: Shows connection prompt
- **Invalid amounts**: Validates before API call
- **Network errors**: Displays user-friendly messages
- **Transaction failures**: Shows detailed error from blockchain
- **Rate limits**: Automatically retries with backoff

## Security Best Practices

1. **Never expose API keys** - All Jupiter API calls go through backend
2. **Validate user inputs** - Check amounts and addresses before submission
3. **Verify transactions** - Always confirm on-chain before showing success
4. **Handle errors gracefully** - Don't expose internal errors to users
5. **Use HTTPS in production** - Protect data in transit

## Performance Optimization

1. **Debounce quote requests** - Wait 500ms after user stops typing
2. **Cache token metadata** - Store token symbols and decimals
3. **Lazy load swap widget** - Only load when needed
4. **Optimize re-renders** - Use React.memo for expensive components

## Advanced Features

### Add Token Selection

Fetch token list from Jupiter:

```typescript
const fetchTokenList = async () => {
  const response = await fetch('https://token.jup.ag/strict');
  const tokens = await response.json();
  return tokens;
};
```

### Add Transaction History

Display user's swap history:

```typescript
const fetchSwapHistory = async (walletAddress: string) => {
  const response = await api.get(`/api/v1/trade/history/${walletAddress}`);
  return response.data;
};
```

### Add Price Charts

Integrate with TradingView or custom charts to show price history.

## Troubleshooting

### Quote not loading
- Check backend is running on correct port
- Verify VITE_SERVER_URL is set correctly
- Check browser console for CORS errors

### Transaction failing
- Ensure wallet has sufficient SOL for transaction + fees
- Check slippage tolerance (increase if market is volatile)
- Verify token addresses are correct

### Tracking not working
- Check MongoDB is running
- Verify signature format is correct
- Check server logs for database errors

## Support

For issues or questions:
- Backend API docs: `whale-trackerV2-2/server/JUPITER_SWAP_API.md`
- Server logs: `whale-trackerV2-2/server/logs/`
- Frontend console: Browser DevTools

## Next Steps

1. Add transaction history page
2. Implement token search/selection
3. Add price impact warnings
4. Create swap analytics dashboard
5. Add mobile-responsive design
6. Implement dark/light theme toggle
